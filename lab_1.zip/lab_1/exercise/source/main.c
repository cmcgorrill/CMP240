/** 
* Lab 1 - GPIO Blinky
* - Drive an LED by GPIO
* - Developer - 
* - Date - 
* 
*/
#include "gpio.h"

// Write a function that will delay for n loops
// to satisfy timing constraints given in lab. 
// ....beware compiler optimization....
void delay(uint32_t count)
{
	
}

int main()
{
	// Select output mode and which pin to drive
        
    while (1)
    {       
        //toggle clear register for the chosen pin
        
        //apply a delay
        
        //toggle set register for the chosen pin
        
        //apply a delay
    }
    
    return 0;
}
